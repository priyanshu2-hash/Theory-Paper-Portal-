import { requireRole } from "@/lib/auth";
import { PortalHeader } from "@/components/PortalHeader";
import { AdminPanel } from "@/components/AdminPanel";

export default async function AdminPage() {
  const profile = await requireRole("admin");
  return (
    <>
      <PortalHeader profile={profile} />
      <main className="shell page-shell"><AdminPanel /></main>
    </>
  );
}
