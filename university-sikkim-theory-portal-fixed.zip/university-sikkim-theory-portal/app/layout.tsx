import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "University of Sikkim · Theory Paper Portal",
  description: "Authenticated theory paper portal for students and administrators.",
  icons: { icon: "/university-sikkim-logo.png" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
