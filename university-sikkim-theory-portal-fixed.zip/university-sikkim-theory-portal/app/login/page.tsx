import { redirect } from "next/navigation";
import { getSessionProfile } from "@/lib/auth";
import { AuthForm } from "@/components/AuthForm";

export default async function LoginPage() {
  const profile = await getSessionProfile();
  if (profile) redirect(profile.role === "admin" ? "/admin" : "/papers");
  return <AuthForm />;
}
