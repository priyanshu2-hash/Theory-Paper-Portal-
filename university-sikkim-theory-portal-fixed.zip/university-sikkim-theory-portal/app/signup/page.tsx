import { redirect } from "next/navigation";
import { getSessionProfile } from "@/lib/auth";
import { SignupForm } from "@/components/SignupForm";

export default async function SignupPage() {
  const profile = await getSessionProfile();
  if (profile) redirect(profile.role === "admin" ? "/admin" : "/papers");
  return <SignupForm />;
}
