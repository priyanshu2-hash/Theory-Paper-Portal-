import { requireRole } from "@/lib/auth";
import { PortalHeader } from "@/components/PortalHeader";
import { PaperExplorer } from "@/components/PaperExplorer";

export default async function PapersPage() {
  const profile = await requireRole("student");
  return (
    <>
      <PortalHeader profile={profile} />
      <main className="shell page-shell"><PaperExplorer /></main>
    </>
  );
}
