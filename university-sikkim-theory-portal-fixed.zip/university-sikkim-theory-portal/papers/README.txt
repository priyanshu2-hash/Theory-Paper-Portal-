Put your University's theory-paper PDF folder here for the optional bulk-upload script.

Recommended command from the project root:
  SUPABASE_URL="https://YOUR-PROJECT.supabase.co" SUPABASE_SERVICE_ROLE_KEY="YOUR-SERVICE-ROLE-KEY" node scripts/upload-papers.mjs ./papers

The script matches files by the exact filenames stored in the paper_catalog table, then uploads them into the private `theory-papers` bucket.
Never expose the service-role key in the browser, .env.local committed to Git, or Vercel client-side variables.
