"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Brand } from "./Brand";
import { createClient } from "@/lib/supabase/client";

export function SignupForm() {
  const router = useRouter();
  const supabase = createClient();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setMessage("");
    if (password.length < 8) {
      setError("Use at least 8 characters for the password.");
      return;
    }
    if (password !== confirm) {
      setError("Passwords do not match.");
      return;
    }

    setBusy(true);
    const { data, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } },
    });

    if (authError) {
      setError(authError.message);
      setBusy(false);
      return;
    }

    if (data.session) {
      router.replace("/papers");
      router.refresh();
      return;
    }

    setMessage("Account created. Check your email if email confirmation is enabled, then sign in.");
    setBusy(false);
  }

  return (
    <main className="auth-page">
      <section className="auth-visual">
        <div className="auth-visual__content">
          <Brand />
          <div className="auth-visual__eyebrow">Student access</div>
          <h1>Your paper library, organized.</h1>
          <p>Create a student account to access the theory paper portal. Your new account is created as a student by default.</p>
        </div>
      </section>
      <section className="auth-form-wrap">
        <div className="auth-card">
          <Brand compact />
          <h2>Create account</h2>
          <p>Register as a student. Administrator privileges are never granted through this form.</p>
          {error && <div className="error-box" role="alert">{error}</div>}
          {message && <div className="success-box" role="status">{message}</div>}
          <form onSubmit={submit}>
            <div className="form-field"><label htmlFor="full-name">Full name</label><input id="full-name" className="form-control" value={fullName} onChange={(e) => setFullName(e.target.value)} required /></div>
            <div className="form-field"><label htmlFor="signup-email">Email address</label><input id="signup-email" className="form-control" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
            <div className="two-col">
              <div className="form-field"><label htmlFor="signup-password">Password</label><input id="signup-password" className="form-control" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" required /></div>
              <div className="form-field"><label htmlFor="signup-confirm">Confirm</label><input id="signup-confirm" className="form-control" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" required /></div>
            </div>
            <button className="button button--primary button--full" type="submit" disabled={busy}>{busy ? "Creating account…" : "Create student account"}</button>
          </form>
          <div className="auth-footer">Already registered? <Link href="/login">Back to sign in</Link></div>
        </div>
      </section>
    </main>
  );
}
