"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { Brand } from "./Brand";

export function AuthForm() {
  const router = useRouter();
  const supabase = createClient();
  const [mode, setMode] = useState<"student" | "admin">("student");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setBusy(true);

    const { data, error: authError } = await supabase.auth.signInWithPassword({ email, password });
    if (authError) {
      setError(authError.message);
      setBusy(false);
      return;
    }

    const user = data.user;
    if (!user) {
      setError("Login completed without a user session. Please try again.");
      setBusy(false);
      return;
    }

    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();

    if (!profile) {
      setError("Your profile is not ready yet. Ask an administrator to complete account setup.");
      await supabase.auth.signOut();
      setBusy(false);
      return;
    }

    if (mode === "admin" && profile.role !== "admin") {
      setError("This account is not marked as an administrator.");
      await supabase.auth.signOut();
      setBusy(false);
      return;
    }

    router.replace(profile.role === "admin" ? "/admin" : "/papers");
    router.refresh();
  }

  return (
    <main className="auth-page">
      <section className="auth-visual">
        <div className="auth-visual__content">
          <Brand />
          <div className="auth-visual__eyebrow">Secure academic access</div>
          <h1>Find the paper.<br />Prepare with purpose.</h1>
          <p>
            A single portal for University of Sikkim students to locate semester-wise theory papers,
            read them in the browser, and download the official PDF when available.
          </p>
          <div className="auth-stat-row">
            <div className="auth-stat"><strong>4</strong><span>Portal types</span></div>
            <div className="auth-stat"><strong>44</strong><span>Programme codes</span></div>
            <div className="auth-stat"><strong>5,695</strong><span>Paper slots in source</span></div>
          </div>
        </div>
      </section>

      <section className="auth-form-wrap">
        <div className="auth-card">
          <Brand compact />
          <h2>Sign in</h2>
          <p>Use your registered account to continue to the academic portal.</p>

          <div className="role-tabs" role="tablist" aria-label="Login role">
            <button className={`role-tab ${mode === "student" ? "active" : ""}`} onClick={() => setMode("student")} type="button">Student</button>
            <button className={`role-tab ${mode === "admin" ? "active" : ""}`} onClick={() => setMode("admin")} type="button">Admin</button>
          </div>

          {error && <div className="error-box" role="alert">{error}</div>}

          <form onSubmit={submit}>
            <div className="form-field">
              <label htmlFor="login-email">Email address</label>
              <input id="login-email" className="form-control" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" required />
            </div>
            <div className="form-field">
              <label htmlFor="login-password">Password</label>
              <input id="login-password" className="form-control" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" autoComplete="current-password" required />
            </div>
            <button className="button button--primary button--full" type="submit" disabled={busy}>
              {busy ? "Signing in…" : mode === "admin" ? "Enter admin panel" : "Open theory papers"}
            </button>
          </form>

          <div className="auth-footer">
            New student account? <Link href="/signup">Create a student login</Link>
            <div className="helper" style={{ marginTop: 10 }}>Administrator accounts are promoted securely in Supabase after the account is created.</div>
          </div>
        </div>
      </section>
    </main>
  );
}
