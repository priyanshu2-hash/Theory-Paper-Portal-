import Link from "next/link";
import { Brand } from "./Brand";
import { LogoutButton } from "./LogoutButton";
import type { Profile } from "@/lib/types";

export function PortalHeader({ profile }: { profile: Profile }) {
  return (
    <header className="portal-header">
      <div className="portal-header__inner shell">
        <Link href={profile.role === "admin" ? "/admin" : "/papers"} className="portal-header__brand-link">
          <Brand compact />
        </Link>
        <div className="portal-header__right">
          <div className="identity">
            <div className="identity__avatar">{(profile.full_name || profile.email || "U").slice(0, 1).toUpperCase()}</div>
            <div className="identity__copy">
              <strong>{profile.full_name || "Portal User"}</strong>
              <span>{profile.role === "admin" ? "Administrator" : "Student"}</span>
            </div>
          </div>
          <LogoutButton />
        </div>
      </div>
    </header>
  );
}
