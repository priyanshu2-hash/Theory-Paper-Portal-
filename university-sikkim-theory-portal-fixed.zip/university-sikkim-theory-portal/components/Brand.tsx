import Image from "next/image";

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand ${compact ? "brand--compact" : ""}`}>
      <Image
        src="/university-sikkim-logo.png"
        alt="University of Sikkim"
        width={244}
        height={78}
        priority
        className="brand__logo"
      />
      {!compact && (
        <div className="brand__text">
          <span>Examination &amp; Academic Resources</span>
          <strong>Theory Paper Portal</strong>
        </div>
      )}
    </div>
  );
}
