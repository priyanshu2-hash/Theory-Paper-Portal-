"use client";

import { useEffect, useMemo, useState } from "react";
import type { CatalogEntry } from "@/lib/types";
import { BUCKET_NAME } from "@/lib/types";
import { createClient } from "@/lib/supabase/client";
import { displayPaperTitle } from "@/lib/storage";

type FilterState = {
  chooseType: string;
  course: string;
  specialization: string;
  semester: string;
};

const EMPTY_FILTERS: FilterState = { chooseType: "", course: "", specialization: "", semester: "" };

// Each catalog row's full set of columns (paper filenames, storage paths…)
// is only ever fetched for the exact combination the student has selected.
// Everything before that point — the four dropdowns — is populated by
// lean RPC calls that return just the handful of distinct values relevant
// to the current selection, not the whole table. See
// supabase/add-catalog-filter-rpcs.sql for the server-side half of this.
export function PaperExplorer() {
  const supabase = createClient();

  const [totalCount, setTotalCount] = useState<number | null>(null);
  const [filters, setFilters] = useState<FilterState>(EMPTY_FILTERS);

  const [chooseTypes, setChooseTypes] = useState<string[]>([]);
  const [courseOptions, setCourseOptions] = useState<string[]>([]);
  const [specializationOptions, setSpecializationOptions] = useState<string[]>([]);
  const [semesterOptions, setSemesterOptions] = useState<string[]>([]);

  const [results, setResults] = useState<CatalogEntry[]>([]);
  const [optionsLoading, setOptionsLoading] = useState(true);
  const [resultsLoading, setResultsLoading] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  // Total catalog size, for the hero stat — a cheap count query instead of
  // loading every row just to read catalog.length.
  useEffect(() => {
    let mounted = true;
    supabase
      .from("paper_catalog")
      .select("*", { count: "exact", head: true })
      .then(({ count, error: countError }) => {
        if (!mounted) return;
        if (!countError) setTotalCount(count ?? 0);
      });
    return () => {
      mounted = false;
    };
  }, [supabase]);

  // Step 1: choose types (always loaded).
  useEffect(() => {
    let mounted = true;
    setOptionsLoading(true);
    setError("");
    supabase
      .rpc("catalog_distinct_choose_types")
      .then(({ data, error: rpcError }) => {
        if (!mounted) return;
        if (rpcError) setError(rpcError.message);
        else setChooseTypes((data || []).map((row: { choose_type: string }) => row.choose_type));
        setOptionsLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, [supabase]);

  // Step 2: courses under the chosen choose type.
  useEffect(() => {
    if (!filters.chooseType) {
      setCourseOptions([]);
      return;
    }
    let mounted = true;
    supabase
      .rpc("catalog_distinct_courses", { p_choose_type: filters.chooseType })
      .then(({ data, error: rpcError }) => {
        if (!mounted) return;
        if (rpcError) setError(rpcError.message);
        else setCourseOptions((data || []).map((row: { course: string }) => row.course));
      });
    return () => {
      mounted = false;
    };
  }, [supabase, filters.chooseType]);

  // Step 3: specializations under the chosen choose type + course.
  useEffect(() => {
    if (!filters.chooseType || !filters.course) {
      setSpecializationOptions([]);
      return;
    }
    let mounted = true;
    supabase
      .rpc("catalog_distinct_specializations", { p_choose_type: filters.chooseType, p_course: filters.course })
      .then(({ data, error: rpcError }) => {
        if (!mounted) return;
        if (rpcError) setError(rpcError.message);
        else setSpecializationOptions((data || []).map((row: { specialization: string }) => row.specialization));
      });
    return () => {
      mounted = false;
    };
  }, [supabase, filters.chooseType, filters.course]);

  // Step 4: semesters under choose type + course + specialization.
  useEffect(() => {
    if (!filters.chooseType || !filters.course || !filters.specialization) {
      setSemesterOptions([]);
      return;
    }
    let mounted = true;
    supabase
      .rpc("catalog_distinct_semesters", {
        p_choose_type: filters.chooseType,
        p_course: filters.course,
        p_specialization: filters.specialization,
      })
      .then(({ data, error: rpcError }) => {
        if (!mounted) return;
        if (rpcError) setError(rpcError.message);
        else setSemesterOptions((data || []).map((row: { semester: number }) => String(row.semester)));
      });
    return () => {
      mounted = false;
    };
  }, [supabase, filters.chooseType, filters.course, filters.specialization]);

  const selected = Boolean(filters.chooseType && filters.course && filters.specialization && filters.semester);

  // Final step: once all four filters are chosen, fetch only the matching
  // rows (there may be more than one, since programme isn't itself a
  // filter) with their full paper filename/path columns.
  useEffect(() => {
    if (!selected) {
      setResults([]);
      return;
    }
    let mounted = true;
    setResultsLoading(true);
    setNotice("");
    supabase
      .from("paper_catalog")
      .select(
        "id, choose_type, programme, course, specialization, semester, paper_1, paper_2, paper_3, paper_1_path, paper_2_path, paper_3_path, created_at, updated_at"
      )
      .eq("choose_type", filters.chooseType)
      .eq("course", filters.course)
      .eq("specialization", filters.specialization)
      .eq("semester", Number(filters.semester))
      .order("programme", { ascending: true })
      .then(({ data, error: queryError }) => {
        if (!mounted) return;
        if (queryError) setError(queryError.message);
        else setResults((data || []) as CatalogEntry[]);
        setResultsLoading(false);
      });
    return () => {
      mounted = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [supabase, selected, filters.chooseType, filters.course, filters.specialization, filters.semester]);

  const filledResults = useMemo(
    () => results.filter((row) => row.paper_1 || row.paper_2 || row.paper_3),
    [results]
  );

  function updateFilter(key: keyof FilterState, value: string) {
    setNotice("");
    setFilters((current) => {
      const next = { ...current, [key]: value };
      if (key === "chooseType") {
        next.course = "";
        next.specialization = "";
        next.semester = "";
      }
      if (key === "course") {
        next.specialization = "";
        next.semester = "";
      }
      if (key === "specialization") {
        next.semester = "";
      }
      return next;
    });
  }

  function reset() {
    setFilters(EMPTY_FILTERS);
    setNotice("");
  }

  async function openPaper(row: CatalogEntry, filename: string | null, explicitPath: string | null, mode: "view" | "download") {
    if (!filename) return;
    setNotice("");
    const path = explicitPath || "";
    if (!path) {
      setNotice(`The catalog has a filename for “${filename}”, but no storage path yet. An administrator needs to upload/re-save this PDF.`);
      return;
    }
    const { data, error: signedError } = await supabase.storage.from(BUCKET_NAME).createSignedUrl(path, 300, { download: mode === "download" });
    if (signedError || !data?.signedUrl) {
      setNotice(signedError?.message || "Could not create a secure PDF link.");
      return;
    }
    window.open(data.signedUrl, "_blank", "noopener,noreferrer");
  }

  return (
    <>
      <section className="hero">
        <div>
          <div className="hero__eyebrow">Student workspace</div>
          <h1>Theory papers, without the hunt.</h1>
          <p>Follow the four-step filter to reach your course, specialisation and semester. PDFs open in a secure, temporary link so the storage bucket can stay private.</p>
        </div>
        <div className="hero__meta"><strong>{totalCount === null ? "…" : totalCount.toLocaleString()}</strong><span>catalog entries</span></div>
      </section>

      <section className="filter-card">
        <div className="filter-grid">
          <div className="form-field">
            <label htmlFor="choose-type">1 · Choose type</label>
            <div className="select-wrap"><select id="choose-type" className="form-control select-control" value={filters.chooseType} onChange={(e) => updateFilter("chooseType", e.target.value)} disabled={optionsLoading}>
              <option value="">Select choose type</option>
              {chooseTypes.map((value) => <option key={value} value={value}>{value}</option>)}
            </select></div>
          </div>
          <div className="form-field">
            <label htmlFor="course">2 · Course</label>
            <div className="select-wrap"><select id="course" className="form-control select-control" value={filters.course} onChange={(e) => updateFilter("course", e.target.value)} disabled={!filters.chooseType}>
              <option value="">Select course</option>
              {courseOptions.map((value) => <option key={value} value={value}>{value}</option>)}
            </select></div>
          </div>
          <div className="form-field">
            <label htmlFor="specialization">3 · Specialization</label>
            <div className="select-wrap"><select id="specialization" className="form-control select-control" value={filters.specialization} onChange={(e) => updateFilter("specialization", e.target.value)} disabled={!filters.course}>
              <option value="">Select specialization</option>
              {specializationOptions.map((value) => <option key={value} value={value}>{value}</option>)}
            </select></div>
          </div>
          <div className="form-field">
            <label htmlFor="semester">4 · Semester</label>
            <div className="select-wrap"><select id="semester" className="form-control select-control" value={filters.semester} onChange={(e) => updateFilter("semester", e.target.value)} disabled={!filters.specialization}>
              <option value="">Select semester</option>
              {semesterOptions.map((value) => <option key={value} value={value}>Semester {value}</option>)}
            </select></div>
          </div>
        </div>
        <div className="filter-actions">
          <div className="filter-state">
            {optionsLoading ? "Loading filter options…" : resultsLoading ? "Looking up matching papers…" : selected ? `${filledResults.reduce((n, x) => n + [x.paper_1, x.paper_2, x.paper_3].filter(Boolean).length, 0)} paper(s) found` : "Choose all four filters to view the matching paper set."}
          </div>
          <button className="button button--ghost" type="button" onClick={reset}>Reset filters</button>
        </div>
      </section>

      {error && <div className="error-box" style={{ marginTop: 16 }}>{error}</div>}
      {notice && <div className="error-box" style={{ marginTop: 16 }}>{notice}</div>}

      <section className="paper-section">
        <div className="result-header"><h2>{selected ? "Matching theory papers" : "Your paper set will appear here"}</h2><span>{selected ? `${results.length} catalog row${results.length === 1 ? "" : "s"}` : "Awaiting your selection"}</span></div>
        {!selected ? (
          <div className="empty-state"><div className="empty-state__icon">⌕</div><h3>Start with Choose Type</h3><p>The next dropdown unlocks only the values that exist under your current selection, keeping the journey focused and preventing invalid combinations.</p></div>
        ) : resultsLoading ? (
          <div className="empty-state"><div className="empty-state__icon">…</div><h3>Looking up your papers</h3><p>Fetching the matching catalog rows.</p></div>
        ) : filledResults.length === 0 ? (
          <div className="empty-state"><div className="empty-state__icon">!</div><h3>No paper PDF is mapped yet</h3><p>The selected academic combination exists in the catalog, but its paper slots are empty. Ask the administrator to upload the required PDFs.</p></div>
        ) : (
          filledResults.map((row) => (
            <article className="entry-block" key={row.id}>
              <div className="entry-head">
                <div className="entry-head__title">
                  <span className="entry-pill">{row.programme}</span>
                  <strong>{row.course}</strong>
                  <span>{row.specialization} · Semester {row.semester}</span>
                </div>
                <span className="entry-pill">{row.choose_type}</span>
              </div>
              <div className="paper-list">
                {[
                  ["Paper 01", row.paper_1, row.paper_1_path],
                  ["Paper 02", row.paper_2, row.paper_2_path],
                  ["Paper 03", row.paper_3, row.paper_3_path],
                ].map(([label, filename, pathValue]) => (
                  <div className="paper-card" key={label as string}>
                    <div>
                      <div className="paper-card__index">{label}</div>
                      {filename ? <h3>{displayPaperTitle(filename as string)}</h3> : <div className="paper-missing">Not mapped</div>}
                    </div>
                    {filename && <div className="paper-card__actions">
                      <button className="button button--dark" type="button" onClick={() => openPaper(row, filename as string, pathValue as string | null, "view")}>View PDF</button>
                      <button className="button button--ghost" type="button" onClick={() => openPaper(row, filename as string, pathValue as string | null, "download")}>Download</button>
                    </div>}
                  </div>
                ))}
              </div>
            </article>
          ))
        )}
      </section>

      <div className="footer-note">University of Sikkim · Theory Paper Portal · Secure academic resource access</div>
    </>
  );
}
