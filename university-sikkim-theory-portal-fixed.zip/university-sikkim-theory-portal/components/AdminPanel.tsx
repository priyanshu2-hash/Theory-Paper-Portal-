"use client";

import { useEffect, useMemo, useState } from "react";
import type { CatalogEntry, Profile, Role } from "@/lib/types";
import { BUCKET_NAME } from "@/lib/types";
import { createClient } from "@/lib/supabase/client";
import { paperStoragePath } from "@/lib/storage";

const blankEntry = {
  choose_type: "",
  programme: "",
  course: "",
  specialization: "",
  semester: 1,
  paper_1: "",
  paper_2: "",
  paper_3: "",
  paper_1_path: "",
  paper_2_path: "",
  paper_3_path: "",
};

export function AdminPanel() {
  const supabase = createClient();
  const [catalog, setCatalog] = useState<CatalogEntry[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [active, setActive] = useState<"overview" | "catalog" | "upload" | "users">("overview");
  const [query, setQuery] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [entry, setEntry] = useState({ ...blankEntry });
  const [uploadCatalogId, setUploadCatalogId] = useState("");
  const [uploadSlot, setUploadSlot] = useState<"paper_1" | "paper_2" | "paper_3">("paper_1");
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [roleSavingId, setRoleSavingId] = useState<string | null>(null);

  async function loadCatalog() {
    const all: CatalogEntry[] = [];
    const pageSize = 1000;
    // No hardcoded row ceiling: the loop only stops when Supabase returns a
    // short page. maxPages is just a safety net against a runaway loop if
    // something upstream misbehaves, not a real limit on catalog size.
    const maxPages = 500; // up to 500,000 rows
    for (let start = 0, pageNum = 0; pageNum < maxPages; start += pageSize, pageNum += 1) {
      const { data, error: e } = await supabase
        .from("paper_catalog")
        .select("*")
        .order("choose_type", { ascending: true })
        .order("course", { ascending: true })
        .order("specialization", { ascending: true })
        .order("semester", { ascending: true })
        .range(start, start + pageSize - 1);
      if (e) throw e;
      const rows = (data || []) as CatalogEntry[];
      all.push(...rows);
      if (rows.length < pageSize) break;
    }
    setCatalog(all);
  }

  async function loadProfiles() {
    const { data, error: e } = await supabase.from("profiles").select("id,full_name,email,role,created_at,updated_at").order("created_at", { ascending: false });
    if (e) throw e;
    setProfiles((data || []) as Profile[]);
  }

  async function refreshAll() {
    setBusy(true); setError("");
    try {
      await Promise.all([loadCatalog(), loadProfiles()]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load admin data.");
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => { refreshAll(); }, []);

  const chooseTypes = useMemo(() => Array.from(new Set(catalog.map((x) => x.choose_type))).sort(), [catalog]);
  const programmeCodes = useMemo(() => Array.from(new Set(catalog.map((x) => x.programme))).sort(), [catalog]);

  const filteredCatalog = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return catalog;
    return catalog.filter((x) => [x.choose_type, x.programme, x.course, x.specialization, String(x.semester), x.paper_1 || "", x.paper_2 || "", x.paper_3 || ""].some((v) => v.toLowerCase().includes(q)));
  }, [catalog, query]);

  const paperCount = useMemo(() => catalog.reduce((total, row) => total + [row.paper_1, row.paper_2, row.paper_3].filter(Boolean).length, 0), [catalog]);
  const uniqueCourses = useMemo(() => new Set(catalog.map((x) => x.course)).size, [catalog]);
  const uniqueSpecializations = useMemo(() => new Set(catalog.map((x) => x.specialization)).size, [catalog]);

  function editRow(row: CatalogEntry) {
    setEditingId(row.id);
    setEntry({
      choose_type: row.choose_type,
      programme: row.programme,
      course: row.course,
      specialization: row.specialization,
      semester: row.semester,
      paper_1: row.paper_1 || "",
      paper_2: row.paper_2 || "",
      paper_3: row.paper_3 || "",
      paper_1_path: row.paper_1_path || "",
      paper_2_path: row.paper_2_path || "",
      paper_3_path: row.paper_3_path || "",
    });
    setActive("catalog");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function newEntry() {
    setEditingId(null);
    setEntry({ ...blankEntry });
    setActive("catalog");
  }

  async function saveEntry(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true); setError(""); setMessage("");
    const payload = {
      choose_type: entry.choose_type.trim(),
      programme: entry.programme.trim(),
      course: entry.course.trim(),
      specialization: entry.specialization.trim(),
      semester: Number(entry.semester),
      paper_1: entry.paper_1.trim() || null,
      paper_2: entry.paper_2.trim() || null,
      paper_3: entry.paper_3.trim() || null,
      paper_1_path: entry.paper_1_path.trim() || null,
      paper_2_path: entry.paper_2_path.trim() || null,
      paper_3_path: entry.paper_3_path.trim() || null,
    };
    if (!payload.choose_type || !payload.programme || !payload.course || !payload.specialization || !payload.semester) {
      setError("Choose Type, Programme, Course, Specialization and Semester are required.");
      setBusy(false);
      return;
    }

    const result = editingId
      ? await supabase.from("paper_catalog").update(payload).eq("id", editingId)
      : await supabase.from("paper_catalog").insert(payload);
    if (result.error) {
      setError(result.error.message);
      setBusy(false);
      return;
    }
    setMessage(editingId ? "Catalog entry updated." : "Catalog entry created.");
    setEditingId(null);
    await loadCatalog();
    setBusy(false);
  }

  async function deleteEntry(id: string) {
    if (!window.confirm("Delete this catalog entry? The database row will be removed; existing PDF files in storage are left untouched.")) return;
    setBusy(true); setError(""); setMessage("");
    const { error: e } = await supabase.from("paper_catalog").delete().eq("id", id);
    if (e) setError(e.message);
    else { setMessage("Catalog entry deleted."); if (editingId === id) newEntry(); await loadCatalog(); }
    setBusy(false);
  }

  async function uploadPaper(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true); setError(""); setMessage("");
    const row = catalog.find((x) => x.id === uploadCatalogId);
    if (!row || !uploadFile) {
      setError("Select a catalog entry and a PDF file.");
      setBusy(false);
      return;
    }
    if (uploadFile.type !== "application/pdf" && !uploadFile.name.toLowerCase().endsWith(".pdf")) {
      setError("Only PDF files are allowed.");
      setBusy(false);
      return;
    }

    const path = paperStoragePath({
      choose_type: row.choose_type,
      programme: row.programme,
      specialization: row.specialization,
      semester: row.semester,
      filename: uploadFile.name,
    });

    const { error: storageError } = await supabase.storage.from(BUCKET_NAME).upload(path, uploadFile, {
      upsert: true,
      contentType: "application/pdf",
      cacheControl: "3600",
    });
    if (storageError) {
      setError(storageError.message);
      setBusy(false);
      return;
    }

    const filenameKey = uploadSlot;
    const pathKey = `${uploadSlot}_path` as "paper_1_path" | "paper_2_path" | "paper_3_path";
    const { error: updateError } = await supabase.from("paper_catalog").update({
      [filenameKey]: uploadFile.name,
      [pathKey]: path,
    }).eq("id", row.id);
    if (updateError) {
      setError(updateError.message);
      setBusy(false);
      return;
    }

    setMessage(`Uploaded ${uploadFile.name} to ${uploadSlot.replace("_", " ")}.`);
    setUploadFile(null);
    await loadCatalog();
    setBusy(false);
  }

  async function changeRole(profile: Profile, role: Role) {
    if (profile.role === role) return;
    if (profile.role === "admin" && role === "student" && !window.confirm(`Demote ${profile.email || profile.full_name || "this admin"} to student?`)) return;
    setRoleSavingId(profile.id); setError("");
    const { error: e } = await supabase.from("profiles").update({ role, updated_at: new Date().toISOString() }).eq("id", profile.id);
    if (e) setError(e.message);
    else { setMessage(`Role updated for ${profile.email || profile.full_name || "user"}.`); await loadProfiles(); }
    setRoleSavingId(null);
  }

  return (
    <div className="admin-layout">
      <aside className="admin-nav">
        <div className="admin-nav__title">Administration</div>
        <button className={`admin-nav__item ${active === "overview" ? "active" : ""}`} onClick={() => setActive("overview")}>Overview</button>
        <button className={`admin-nav__item ${active === "catalog" ? "active" : ""}`} onClick={() => setActive("catalog")}>Catalog manager</button>
        <button className={`admin-nav__item ${active === "upload" ? "active" : ""}`} onClick={() => setActive("upload")}>Upload PDF</button>
        <button className={`admin-nav__item ${active === "users" ? "active" : ""}`} onClick={() => setActive("users")}>User roles</button>
      </aside>

      <div className="admin-content">
        {(message || error) && <div className={error ? "error-box" : "success-box"}>{error || message}</div>}
        {active === "overview" && (
          <>
            <div className="hero" style={{ marginBottom: 16 }}>
              <div><div className="hero__eyebrow">Administrator workspace</div><h1>Portal control room.</h1><p>Manage the academic catalog, map PDF files, and maintain student/admin roles. The underlying RLS rules keep these actions restricted to administrators.</p></div>
            </div>
            <div className="kpi-grid">
              <div className="kpi-card"><strong>{catalog.length.toLocaleString()}</strong><span>Catalog entries</span></div>
              <div className="kpi-card"><strong>{paperCount.toLocaleString()}</strong><span>Filled paper slots</span></div>
              <div className="kpi-card"><strong>{uniqueCourses.toLocaleString()}</strong><span>Courses</span></div>
              <div className="kpi-card"><strong>{uniqueSpecializations.toLocaleString()}</strong><span>Specializations</span></div>
            </div>
            <div className="admin-card"><div className="admin-card__head"><div><h2>Quick actions</h2><p>Common administrator tasks.</p></div></div><div className="admin-toolbar"><button className="button button--primary" onClick={newEntry}>+ New catalog entry</button><button className="button button--dark" onClick={() => setActive("upload")}>Upload a PDF</button><button className="button button--ghost" onClick={refreshAll} disabled={busy}>{busy ? "Refreshing…" : "Refresh data"}</button></div></div>
          </>
        )}

        {active === "catalog" && (
          <>
            <div className="admin-card">
              <div className="admin-card__head"><div><h2>{editingId ? "Edit catalog entry" : "Create catalog entry"}</h2><p>Each row represents one choose-type + programme + course + specialization + semester combination.</p></div><button className="button button--ghost" onClick={newEntry}>Clear</button></div>
              <form onSubmit={saveEntry}>
                <div className="admin-form-grid">
                  <div className="form-field"><label>Choose Type</label><input className="form-control" list="choose-types" value={entry.choose_type} onChange={(e) => setEntry({ ...entry, choose_type: e.target.value })} required /><datalist id="choose-types">{chooseTypes.map((x) => <option key={x} value={x} />)}</datalist></div>
                  <div className="form-field"><label>Programme code</label><input className="form-control" list="programme-codes" value={entry.programme} onChange={(e) => setEntry({ ...entry, programme: e.target.value })} required /><datalist id="programme-codes">{programmeCodes.map((x) => <option key={x} value={x} />)}</datalist></div>
                  <div className="form-field"><label>Course</label><input className="form-control" value={entry.course} onChange={(e) => setEntry({ ...entry, course: e.target.value })} required /></div>
                  <div className="form-field"><label>Specialization</label><input className="form-control" value={entry.specialization} onChange={(e) => setEntry({ ...entry, specialization: e.target.value })} required /></div>
                  <div className="form-field"><label>Semester</label><input className="form-control" type="number" min="1" max="20" value={entry.semester} onChange={(e) => setEntry({ ...entry, semester: Number(e.target.value) })} required /></div>
                  <div className="form-field"><label>Paper 1 filename</label><input className="form-control" value={entry.paper_1} onChange={(e) => setEntry({ ...entry, paper_1: e.target.value })} placeholder="Example.pdf" /></div>
                  <div className="form-field"><label>Paper 2 filename</label><input className="form-control" value={entry.paper_2} onChange={(e) => setEntry({ ...entry, paper_2: e.target.value })} /></div>
                  <div className="form-field"><label>Paper 3 filename</label><input className="form-control" value={entry.paper_3} onChange={(e) => setEntry({ ...entry, paper_3: e.target.value })} /></div>
                </div>
                <div className="admin-toolbar" style={{ marginTop: 14 }}><button className="button button--primary" disabled={busy}>{busy ? "Saving…" : editingId ? "Save changes" : "Create entry"}</button></div>
              </form>
            </div>
            <div className="admin-card">
              <div className="admin-card__head"><div><h2>Catalog</h2><p>{filteredCatalog.length.toLocaleString()} matching rows</p></div><input className="form-control" style={{ maxWidth: 330 }} placeholder="Search course, specialization, filename…" value={query} onChange={(e) => setQuery(e.target.value)} /></div>
              <div className="table-wrap"><table><thead><tr><th>Choose</th><th>Programme</th><th>Course / Specialization</th><th>Sem</th><th>PDFs</th><th>Actions</th></tr></thead><tbody>{filteredCatalog.slice(0, 250).map((row) => <tr key={row.id}><td>{row.choose_type}</td><td><span className="badge">{row.programme}</span></td><td><strong>{row.course}</strong><br /><span className="helper">{row.specialization}</span></td><td>{row.semester}</td><td>{[row.paper_1, row.paper_2, row.paper_3].filter(Boolean).length}/3</td><td><div className="inline-actions"><button className="small-button" onClick={() => editRow(row)}>Edit</button><button className="small-button small-button--red" onClick={() => deleteEntry(row.id)}>Delete</button></div></td></tr>)}</tbody></table></div>
              {filteredCatalog.length > 250 && <div className="helper" style={{ marginTop: 10 }}>Showing first 250 results. Use the search box to narrow the catalog.</div>}
            </div>
          </>
        )}

        {active === "upload" && (
          <div className="admin-card">
            <div className="admin-card__head"><div><h2>Upload theory paper PDF</h2><p>Select an existing catalog entry, choose one of its three paper slots, and upload the PDF directly to private Supabase Storage.</p></div></div>
            <form onSubmit={uploadPaper}>
              <div className="form-field"><label>Catalog entry</label><select className="form-control" value={uploadCatalogId} onChange={(e) => setUploadCatalogId(e.target.value)} required><option value="">Select entry</option>{catalog.map((row) => <option key={row.id} value={row.id}>{row.programme} · {row.specialization} · Sem {row.semester} · {row.choose_type}</option>)}</select></div>
              <div className="two-col">
                <div className="form-field"><label>Paper slot</label><select className="form-control" value={uploadSlot} onChange={(e) => setUploadSlot(e.target.value as "paper_1" | "paper_2" | "paper_3")}><option value="paper_1">Paper 1</option><option value="paper_2">Paper 2</option><option value="paper_3">Paper 3</option></select></div>
                <div className="form-field"><label>PDF file</label><input className="form-control" type="file" accept="application/pdf,.pdf" onChange={(e) => setUploadFile(e.target.files?.[0] || null)} required /></div>
              </div>
              <div className="helper" style={{ marginBottom: 14 }}>The portal stores the PDF in a private bucket and students receive a temporary signed URL when they click View or Download.</div>
              <button className="button button--primary" disabled={busy}>{busy ? "Uploading…" : "Upload PDF"}</button>
            </form>
          </div>
        )}

        {active === "users" && (
          <div className="admin-card">
            <div className="admin-card__head"><div><h2>User roles</h2><p>Student accounts are created through sign-up. Use this table to promote an existing account to admin or return it to student.</p></div></div>
            <div className="table-wrap"><table><thead><tr><th>User</th><th>Email</th><th>Joined</th><th>Role</th><th>Change</th></tr></thead><tbody>{profiles.map((profile) => <tr key={profile.id}><td>{profile.full_name || "—"}</td><td>{profile.email || "—"}</td><td>{new Date(profile.created_at).toLocaleDateString()}</td><td><span className={`badge ${profile.role === "admin" ? "badge--admin" : ""}`}>{profile.role}</span></td><td><select className="form-control" value={profile.role} disabled={roleSavingId === profile.id} onChange={(e) => changeRole(profile, e.target.value as Role)} style={{ minWidth: 120 }}><option value="student">Student</option><option value="admin">Admin</option></select></td></tr>)}</tbody></table></div>
          </div>
        )}

        <div className="footer-note">Admin actions are enforced again by Supabase Row Level Security; hiding the admin UI alone is not the security boundary.</div>
      </div>
    </div>
  );
}
