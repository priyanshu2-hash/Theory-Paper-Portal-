-- Adds lean "distinct value" lookups for the cascading student filter UI.
--
-- Previously PaperExplorer.tsx (and AdminPanel.tsx) loaded the *entire*
-- paper_catalog table to the browser on every page load, just so the four
-- cascading <select> dropdowns could compute their own distinct option
-- lists client-side. That doesn't scale: every student visit re-downloads
-- the whole catalog (currently ~2,300 rows, but growing).
--
-- These functions push that work into Postgres instead, so the browser only
-- ever asks for the small number of distinct values relevant to the
-- dropdown currently being populated, plus the exact matching rows once all
-- four filters are chosen. They're marked SECURITY INVOKER (the default),
-- so they run with the caller's own privileges and are still governed by
-- paper_catalog's existing RLS policies — an anonymous (non-authenticated)
-- caller still gets zero rows back, exactly as before.
--
-- Safe to run on an existing project: every statement is idempotent.

create or replace function public.catalog_distinct_choose_types()
returns table (choose_type text)
language sql
stable
security invoker
as $$
  select distinct choose_type
  from public.paper_catalog
  order by choose_type;
$$;

create or replace function public.catalog_distinct_courses(p_choose_type text)
returns table (course text)
language sql
stable
security invoker
as $$
  select distinct course
  from public.paper_catalog
  where choose_type = p_choose_type
  order by course;
$$;

create or replace function public.catalog_distinct_specializations(p_choose_type text, p_course text)
returns table (specialization text)
language sql
stable
security invoker
as $$
  select distinct specialization
  from public.paper_catalog
  where choose_type = p_choose_type
    and course = p_course
  order by specialization;
$$;

create or replace function public.catalog_distinct_semesters(p_choose_type text, p_course text, p_specialization text)
returns table (semester integer)
language sql
stable
security invoker
as $$
  select distinct semester
  from public.paper_catalog
  where choose_type = p_choose_type
    and course = p_course
    and specialization = p_specialization
  order by semester;
$$;
