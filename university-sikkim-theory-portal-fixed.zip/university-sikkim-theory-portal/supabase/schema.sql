-- University of Sikkim Theory Paper Portal
-- Supabase database + storage security setup.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  role text not null default 'student' check (role in ('student', 'admin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.paper_catalog (
  id uuid primary key default gen_random_uuid(),
  choose_type text not null,
  programme text not null,
  course text not null,
  specialization text not null,
  semester integer not null check (semester between 1 and 20),
  paper_1 text,
  paper_2 text,
  paper_3 text,
  paper_1_path text,
  paper_2_path text,
  paper_3_path text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (choose_type, programme, course, specialization, semester)
);

create index if not exists paper_catalog_filters_idx
  on public.paper_catalog (choose_type, course, specialization, semester);

create or replace function public.is_admin(uid uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles
    where id = uid
      and role = 'admin'
  );
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    new.email,
    'student'
  )
  on conflict (id) do update set
    email = excluded.email,
    full_name = coalesce(excluded.full_name, public.profiles.full_name),
    updated_at = now();
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.paper_catalog enable row level security;

-- Profiles: users can read their own profile; admins can read/update all profiles.
drop policy if exists "profiles_select_own_or_admin" on public.profiles;
create policy "profiles_select_own_or_admin"
  on public.profiles for select
  to authenticated
  using (id = auth.uid() or public.is_admin());

drop policy if exists "profiles_update_admin" on public.profiles;
create policy "profiles_update_admin"
  on public.profiles for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- Catalog: authenticated users can view; only admins can change it.
drop policy if exists "catalog_select_authenticated" on public.paper_catalog;
create policy "catalog_select_authenticated"
  on public.paper_catalog for select
  to authenticated
  using (true);

drop policy if exists "catalog_insert_admin" on public.paper_catalog;
create policy "catalog_insert_admin"
  on public.paper_catalog for insert
  to authenticated
  with check (public.is_admin());

drop policy if exists "catalog_update_admin" on public.paper_catalog;
create policy "catalog_update_admin"
  on public.paper_catalog for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "catalog_delete_admin" on public.paper_catalog;
create policy "catalog_delete_admin"
  on public.paper_catalog for delete
  to authenticated
  using (public.is_admin());

-- Private Storage bucket for PDFs.
insert into storage.buckets (id, name, public)
values ('theory-papers', 'theory-papers', false)
on conflict (id) do update set public = false;

-- Authenticated students/admins may generate signed URLs / read metadata.
drop policy if exists "theory_papers_select_authenticated" on storage.objects;
create policy "theory_papers_select_authenticated"
  on storage.objects for select
  to authenticated
  using (bucket_id = 'theory-papers');

-- Only admins can upload/update/delete PDFs.
drop policy if exists "theory_papers_insert_admin" on storage.objects;
create policy "theory_papers_insert_admin"
  on storage.objects for insert
  to authenticated
  with check (bucket_id = 'theory-papers' and public.is_admin());

drop policy if exists "theory_papers_update_admin" on storage.objects;
create policy "theory_papers_update_admin"
  on storage.objects for update
  to authenticated
  using (bucket_id = 'theory-papers' and public.is_admin())
  with check (bucket_id = 'theory-papers' and public.is_admin());

drop policy if exists "theory_papers_delete_admin" on storage.objects;
create policy "theory_papers_delete_admin"
  on storage.objects for delete
  to authenticated
  using (bucket_id = 'theory-papers' and public.is_admin());

-- Lean "distinct value" lookups for the cascading student filter UI, so the
-- browser never has to download the whole catalog just to populate four
-- dropdowns. See add-catalog-filter-rpcs.sql for the full explanation; that
-- file is also safe to re-run standalone against an existing project.
create or replace function public.catalog_distinct_choose_types()
returns table (choose_type text)
language sql
stable
security invoker
as $$
  select distinct choose_type
  from public.paper_catalog
  order by choose_type;
$$;

create or replace function public.catalog_distinct_courses(p_choose_type text)
returns table (course text)
language sql
stable
security invoker
as $$
  select distinct course
  from public.paper_catalog
  where choose_type = p_choose_type
  order by course;
$$;

create or replace function public.catalog_distinct_specializations(p_choose_type text, p_course text)
returns table (specialization text)
language sql
stable
security invoker
as $$
  select distinct specialization
  from public.paper_catalog
  where choose_type = p_choose_type
    and course = p_course
  order by specialization;
$$;

create or replace function public.catalog_distinct_semesters(p_choose_type text, p_course text, p_specialization text)
returns table (semester integer)
language sql
stable
security invoker
as $$
  select distinct semester
  from public.paper_catalog
  where choose_type = p_choose_type
    and course = p_course
    and specialization = p_specialization
  order by semester;
$$;

-- Helpful function for admin dashboards.
create or replace function public.catalog_stats()
returns table (
  catalog_rows bigint,
  paper_slots bigint,
  filled_paper_slots bigint
)
language sql
security invoker
as $$
  select
    count(*)::bigint as catalog_rows,
    (count(*) * 3)::bigint as paper_slots,
    sum((case when paper_1 is not null and paper_1 <> '' then 1 else 0 end)
      + (case when paper_2 is not null and paper_2 <> '' then 1 else 0 end)
      + (case when paper_3 is not null and paper_3 <> '' then 1 else 0 end))::bigint
      as filled_paper_slots
  from public.paper_catalog;
$$;
