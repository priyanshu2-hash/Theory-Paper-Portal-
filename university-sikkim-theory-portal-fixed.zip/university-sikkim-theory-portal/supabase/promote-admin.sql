-- 1) Create the user normally from the portal's Sign Up page.
-- 2) Replace the email below with your admin email and run this SQL in Supabase.

update public.profiles
set role = 'admin', updated_at = now()
where email = 'YOUR-ADMIN-EMAIL@example.com';

-- Verify:
select id, full_name, email, role from public.profiles where email = 'YOUR-ADMIN-EMAIL@example.com';
