# University of Sikkim — Theory Paper Portal

A deployable Next.js 16.3.8 + Supabase portal for University of Sikkim theory papers. The project pins Next.js 16.3.8, `@supabase/ssr` 0.12.7, and `@supabase/supabase-js` 2.117.2.

## What is included

- University of Sikkim logo from the supplied image.
- Student login and student sign-up.
- Separate Admin login tab.
- Secure cookie-based Supabase Auth integration.
- Cascading filters: Choose Type → Course → Specialization → Semester.
- Theory-paper result cards with View PDF and Download actions.
- Private Supabase Storage bucket with temporary signed PDF links.
- Admin dashboard with:
  - catalog overview
  - create/edit/delete catalog rows
  - direct PDF upload to Storage
  - user role management
- PostgreSQL Row Level Security policies so only admins can change catalog/storage/user roles.
- Seed SQL generated from `Theor paper project sheet .xlsx` supplied for this build.
- Optional bulk PDF folder uploader.

## Source data imported

The supplied workbook contains 2,326 source rows across 4 choose types and 44 programme codes. Two exact duplicate catalog keys were present as blank duplicate rows; the generated seed keeps the populated row so the filter selection is unambiguous. The resulting catalog has 2,324 rows, 5,695 non-empty theory-paper filename slots, and 1,277 empty paper slots.

## 1. Create a Supabase project

Create a Supabase project at https://database.new.

In Supabase → SQL Editor:

1. Run `supabase/schema.sql`.
2. Run `supabase/seed.sql`.

The seed file is generated directly from the uploaded Excel workbook. It is safe to re-run because it uses the catalog's unique key with `ON CONFLICT ... DO UPDATE`.

If you already have a project set up from an earlier version of this repo (before the server-side filter RPCs were added to `schema.sql`), run `supabase/add-catalog-filter-rpcs.sql` once in the SQL Editor to pick them up — it's idempotent and safe to run on an existing project.

## 2. Create the first admin

Open the portal locally and use **Create a student login**, or create an account in Supabase Auth.

Then edit `supabase/promote-admin.sql`, replace the email, and run that SQL in Supabase.

After the promotion, use the **Admin** tab on `/login`.

## 3. Configure environment variables

Copy `.env.example` to `.env.local`:

```bash
NEXT_PUBLIC_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

Do not put a Supabase service-role key in these `NEXT_PUBLIC_*` variables.

## 4. Run locally

Node.js 22+ is required: Next.js 16 itself needs 20.9+, but the pinned `@supabase/supabase-js` (2.117.2) dropped Node 20 support as of its 2.110.0 release, so 22+ is the real floor for this project.

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## 5. Upload the PDF library

For a smaller library, use **Admin → Upload PDF** and upload each paper into its Paper 1/2/3 slot.

For a large existing folder, use the optional bulk uploader. It matches the exact filenames in the catalog seed:

```bash
SUPABASE_URL="https://YOUR-PROJECT.supabase.co" \
SUPABASE_SERVICE_ROLE_KEY="YOUR-SERVICE-ROLE-KEY" \
node scripts/upload-papers.mjs ./papers
```

Use the service-role key only in this local/server-side script. Never expose it to the browser.

## 5b. Clean up orphaned PDFs (optional)

Deleting a catalog entry, re-uploading a paper to a new slot, or editing a row's choose-type/programme/specialization after a PDF was already uploaded can leave old PDF objects behind in storage with nothing pointing to them. `scripts/cleanup-orphaned-papers.mjs` lists (and, with `--delete`, removes) any object in the `theory-papers` bucket that no catalog row references:

```bash
SUPABASE_URL="https://YOUR-PROJECT.supabase.co" \
SUPABASE_SERVICE_ROLE_KEY="YOUR-SERVICE-ROLE-KEY" \
node scripts/cleanup-orphaned-papers.mjs            # dry run, lists orphans only

SUPABASE_URL="..." SUPABASE_SERVICE_ROLE_KEY="..." \
node scripts/cleanup-orphaned-papers.mjs --delete   # actually deletes them
```

## 6. Deploy to Vercel

1. Push this folder to GitHub.
2. Import the repository into Vercel.
3. Add the two `NEXT_PUBLIC_*` environment variables in Project Settings.
4. Deploy.
5. In Supabase Auth settings, configure the production Site URL / redirect URLs to your Vercel domain.

The app uses Next.js App Router and Supabase's current SSR approach, with `proxy.ts` refreshing the Auth session.

## Security model

- Students and admins must authenticate.
- Student users can read the paper catalog.
- Only admin users can create/update/delete catalog rows.
- Only admin users can upload/update/delete PDF objects in the private `theory-papers` bucket.
- PDF viewing uses signed URLs instead of making the bucket public.
- Admin role checks are enforced in both the application and Supabase RLS policies.

## Notes about the supplied workbook

The Excel file contains a mix of populated and empty paper slots. Empty slots remain empty in the seed and appear as “Not mapped” in the admin/student UI until a PDF is uploaded.

## Official docs used for the implementation

Next.js: https://nextjs.org/docs
Supabase Next.js Auth: https://supabase.com/docs/guides/auth/quickstarts/nextjs
Supabase SSR Auth: https://supabase.com/docs/guides/auth/server-side
Supabase Storage: https://supabase.com/docs/guides/storage/quickstart
