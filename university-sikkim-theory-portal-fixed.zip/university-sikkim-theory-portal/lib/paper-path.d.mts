export declare function slugify(value: string): string;

export declare function paperStoragePath(input: {
  choose_type: string;
  programme: string;
  specialization: string;
  semester: number;
  filename: string;
}): string;

export declare function displayPaperTitle(filename: string): string;
