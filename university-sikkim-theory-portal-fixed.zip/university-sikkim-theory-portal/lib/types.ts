export type Role = "student" | "admin";

export type Profile = {
  id: string;
  full_name: string | null;
  email: string | null;
  role: Role;
  created_at: string;
  updated_at?: string;
};

export type CatalogEntry = {
  id: string;
  choose_type: string;
  programme: string;
  course: string;
  specialization: string;
  semester: number;
  paper_1: string | null;
  paper_2: string | null;
  paper_3: string | null;
  paper_1_path: string | null;
  paper_2_path: string | null;
  paper_3_path: string | null;
  created_at: string;
  updated_at: string;
};

export type CatalogDraft = Omit<
  CatalogEntry,
  "id" | "created_at" | "updated_at"
>;

export const BUCKET_NAME = "theory-papers";
