import { redirect } from "next/navigation";
import type { Role, Profile } from "./types";
import { createClient } from "./supabase/server";

export async function getSessionProfile(): Promise<Profile | null> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const { data: profile } = await supabase
    .from("profiles")
    .select("id, full_name, email, role, created_at, updated_at")
    .eq("id", user.id)
    .single();

  if (!profile) return null;
  return profile as Profile;
}

export async function requireRole(role: Role): Promise<Profile> {
  const profile = await getSessionProfile();
  if (!profile) {
    redirect("/login");
    throw new Error("Unauthenticated");
  }
  if (profile.role !== role) {
    redirect(profile.role === "admin" ? "/admin" : "/papers");
    throw new Error("Wrong role");
  }
  return profile;
}
