// Thin TypeScript re-export over the canonical path-building logic in
// lib/paper-path.mjs. That plain-JS module is the single source of truth,
// shared with scripts/upload-papers.mjs and scripts/cleanup-orphaned-papers.mjs,
// so the app and the standalone CLI scripts can never drift apart on how a
// storage path is built.
export { slugify, paperStoragePath, displayPaperTitle } from "./paper-path.mjs";
