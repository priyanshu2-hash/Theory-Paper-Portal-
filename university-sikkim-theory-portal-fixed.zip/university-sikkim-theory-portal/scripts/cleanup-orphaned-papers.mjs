// Finds (and optionally deletes) PDF objects in the private `theory-papers`
// storage bucket that are no longer referenced by any paper_catalog row.
//
// Why this exists: deleting a catalog entry in the admin panel removes the
// database row but intentionally leaves the PDF in storage untouched (the
// admin UI tells you this in its confirm dialog). Re-uploading a paper to a
// new slot, or editing a catalog row's choose_type/programme/specialization
// after a PDF was already uploaded under the old path, can also leave the
// old object behind. Over time these orphaned objects just sit in the
// bucket, taking up storage quota with nothing pointing to them. This
// script is the cleanup tool for that drift.
//
// Usage (dry run — lists orphans, deletes nothing):
//   SUPABASE_URL="https://YOUR-PROJECT.supabase.co" \
//   SUPABASE_SERVICE_ROLE_KEY="YOUR-SERVICE-ROLE-KEY" \
//   node scripts/cleanup-orphaned-papers.mjs
//
// Usage (actually delete the orphans found):
//   SUPABASE_URL="..." SUPABASE_SERVICE_ROLE_KEY="..." \
//   node scripts/cleanup-orphaned-papers.mjs --delete
//
// Never expose the service-role key in the browser, in a committed
// .env file, or in a Vercel client-side (NEXT_PUBLIC_*) variable.

import process from 'node:process';
import { createClient } from '@supabase/supabase-js';

const url = process.env.SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const shouldDelete = process.argv.includes('--delete');

if (!url || !serviceKey) {
  console.error('Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY before running this script.');
  process.exit(1);
}

const supabase = createClient(url, serviceKey, { auth: { persistSession: false } });
const bucket = 'theory-papers';

// Storage "folders" are just path prefixes, not real directories, so object
// listing has to be walked recursively one prefix at a time.
async function listAllObjectPaths(prefix = '') {
  const paths = [];
  const pageSize = 1000;
  let offset = 0;

  for (;;) {
    const { data, error } = await supabase.storage.from(bucket).list(prefix, {
      limit: pageSize,
      offset,
      sortBy: { column: 'name', order: 'asc' },
    });
    if (error) throw error;
    if (!data || data.length === 0) break;

    for (const item of data) {
      const fullPath = prefix ? `${prefix}/${item.name}` : item.name;
      // Objects returned by Storage's list() have an `id`; pseudo-folders
      // (prefixes with no object of their own) come back with `id: null`.
      if (item.id === null) {
        paths.push(...(await listAllObjectPaths(fullPath)));
      } else {
        paths.push(fullPath);
      }
    }

    if (data.length < pageSize) break;
    offset += pageSize;
  }

  return paths;
}

async function loadReferencedPaths() {
  const referenced = new Set();
  const pageSize = 1000;
  let start = 0;

  for (;;) {
    const { data, error } = await supabase
      .from('paper_catalog')
      .select('paper_1_path, paper_2_path, paper_3_path')
      .range(start, start + pageSize - 1);
    if (error) throw error;
    if (!data || data.length === 0) break;

    for (const row of data) {
      for (const p of [row.paper_1_path, row.paper_2_path, row.paper_3_path]) {
        if (p) referenced.add(p);
      }
    }

    if (data.length < pageSize) break;
    start += pageSize;
  }

  return referenced;
}

console.log(`Scanning bucket "${bucket}" for orphaned PDF objects…`);

const [allObjectPaths, referencedPaths] = await Promise.all([
  listAllObjectPaths(),
  loadReferencedPaths(),
]);

const orphaned = allObjectPaths.filter((p) => !referencedPaths.has(p));

console.log(`Objects in storage: ${allObjectPaths.length}`);
console.log(`Paths referenced by paper_catalog: ${referencedPaths.size}`);
console.log(`Orphaned objects found: ${orphaned.length}`);

if (orphaned.length === 0) {
  console.log('Nothing to clean up.');
  process.exit(0);
}

for (const p of orphaned) console.log(`  [ORPHAN] ${p}`);

if (!shouldDelete) {
  console.log('\nDry run only — no files were deleted. Re-run with --delete to remove the objects listed above.');
  process.exit(0);
}

console.log('\nDeleting orphaned objects…');
// Storage's remove() accepts up to 1000 paths per call.
const batchSize = 1000;
let deleted = 0;
let failed = 0;

for (let i = 0; i < orphaned.length; i += batchSize) {
  const batch = orphaned.slice(i, i + batchSize);
  const { data, error } = await supabase.storage.from(bucket).remove(batch);
  if (error) {
    console.error(`[FAIL] batch starting at ${i}: ${error.message}`);
    failed += batch.length;
    continue;
  }
  deleted += data?.length ?? batch.length;
}

console.log(`Done. Deleted: ${deleted}; failed: ${failed}.`);
