import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import { createClient } from '@supabase/supabase-js';
import { paperStoragePath } from '../lib/paper-path.mjs';

const url = process.env.SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const folder = process.argv[2] || './papers';

if (!url || !serviceKey) {
  console.error('Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY before running this script.');
  process.exit(1);
}

const supabase = createClient(url, serviceKey, { auth: { persistSession: false } });
const bucket = 'theory-papers';

// Path building now comes from lib/paper-path.mjs — the same module the
// Next.js app uses — so this script can never drift from the app's paths.
function storagePath(row, filename) {
  return paperStoragePath({
    choose_type: row.choose_type,
    programme: row.programme,
    specialization: row.specialization,
    semester: row.semester,
    filename,
  });
}

async function walk(dir) {
  const items = await fs.readdir(dir, { withFileTypes: true });
  const files = [];
  for (const item of items) {
    const full = path.join(dir, item.name);
    if (item.isDirectory()) files.push(...await walk(full));
    else files.push(full);
  }
  return files;
}

const { data: rows, error } = await supabase.from('paper_catalog').select('*');
if (error) throw error;

const index = new Map();
for (const row of rows || []) {
  for (const key of ['paper_1', 'paper_2', 'paper_3']) {
    const filename = row[key];
    if (!filename) continue;
    const normalized = filename.trim().toLowerCase();
    const current = index.get(normalized) || [];
    current.push({ row, key });
    index.set(normalized, current);
  }
}

const files = (await walk(folder)).filter((f) => f.toLowerCase().endsWith('.pdf'));
console.log(`Found ${files.length} PDF files in ${folder}.`);
let uploaded = 0;
let skipped = 0;
let failed = 0;

for (const file of files) {
  const filename = path.basename(file);
  const matches = index.get(filename.toLowerCase()) || [];
  if (matches.length !== 1) {
    console.warn(`[SKIP] ${filename} -> expected exactly one catalog slot, found ${matches.length}`);
    skipped += 1;
    continue;
  }

  const { row, key } = matches[0];
  const objectPath = storagePath(row, filename);
  try {
    const body = await fs.readFile(file);
    const { error: uploadError } = await supabase.storage.from(bucket).upload(objectPath, body, {
      upsert: true,
      contentType: 'application/pdf',
      cacheControl: '3600',
    });
    if (uploadError) throw uploadError;

    const pathKey = `${key}_path`;
    const { error: updateError } = await supabase.from('paper_catalog').update({ [pathKey]: objectPath, [key]: filename }).eq('id', row.id);
    if (updateError) throw updateError;

    uploaded += 1;
    console.log(`[OK] ${filename}`);
  } catch (e) {
    failed += 1;
    console.error(`[FAIL] ${filename}: ${e.message}`);
  }
}

console.log(`Done. Uploaded: ${uploaded}; skipped: ${skipped}; failed: ${failed}.`);
